# Django
from django.urls import path

# Local Models
from polls import views

urlpatterns = [
  path('', views.index, name='index'),
]