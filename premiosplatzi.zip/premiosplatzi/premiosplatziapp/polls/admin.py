# Django
from django.contrib import admin

# Local Models
from polls.models import Question

admin.site.register(Question)